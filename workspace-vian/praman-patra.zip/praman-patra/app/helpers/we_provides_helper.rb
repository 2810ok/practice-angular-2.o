module WeProvidesHelper
end
