module SmartCardsHelper
end
