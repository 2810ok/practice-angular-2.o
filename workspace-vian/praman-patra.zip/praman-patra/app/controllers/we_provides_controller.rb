class WeProvidesController < ApplicationController
  def index
  end
end
