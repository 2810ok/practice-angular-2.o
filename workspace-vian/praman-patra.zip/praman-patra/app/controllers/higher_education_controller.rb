class HigherEducationController < ApplicationController
    def index
        # Add any logic here if needed
      end
end
