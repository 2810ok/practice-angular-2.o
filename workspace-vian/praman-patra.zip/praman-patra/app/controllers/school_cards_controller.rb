class SchoolCardsController < ApplicationController
  def index
  end
end
