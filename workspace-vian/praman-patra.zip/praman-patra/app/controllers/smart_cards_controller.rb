class SmartCardsController < ApplicationController
  def index
  end
end
