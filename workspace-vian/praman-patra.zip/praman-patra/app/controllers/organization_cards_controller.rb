class OrganizationCardsController < ApplicationController
  def index
  end
end
