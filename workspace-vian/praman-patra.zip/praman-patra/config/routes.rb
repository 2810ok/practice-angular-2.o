Rails.application.routes.draw do
  get 'about_us/index'
  get 'learning/index'
  get 'we_provides/index'
  get 'contents/index'
  get 'faq/index'
  get 'samples/index'
  get 'verification/index'
  get 'smart_cards/index'
  get 'organization_cards/index'
  get 'school_cards/index'
  devise_for :users
  get 'home/index'
root to: 'home#index'

get '/school_cards', to: 'school_cards#index'
get '/organization-cards', to: 'organization_cards#index'
get '/smart-cards', to: 'smart_cards#index'
get '/verification-page', to: 'verification#index'
get '/samples', to: 'samples#index'
get '/faq', to: 'faq#index'
get '/contents', to: 'contents#index'
get '/we-provides', to: 'we_provides#index'
get '/learning', to: 'learning#index'
get '/about-us', to: 'about_us#index'
get '/higher_education', to: 'higher_education#index'

  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check

  # Defines the root path route ("/")
  # root "posts#index"
end
