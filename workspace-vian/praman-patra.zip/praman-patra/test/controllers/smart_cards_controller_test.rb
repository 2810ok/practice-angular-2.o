require "test_helper"

class SmartCardsControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get smart_cards_index_url
    assert_response :success
  end
end
