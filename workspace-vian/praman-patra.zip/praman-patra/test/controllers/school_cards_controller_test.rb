require "test_helper"

class SchoolCardsControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get school_cards_index_url
    assert_response :success
  end
end
