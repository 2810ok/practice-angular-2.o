require "test_helper"

class OrganizationCardsControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get organization_cards_index_url
    assert_response :success
  end
end
