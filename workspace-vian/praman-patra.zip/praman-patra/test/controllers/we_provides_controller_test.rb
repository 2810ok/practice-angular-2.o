require "test_helper"

class WeProvidesControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get we_provides_index_url
    assert_response :success
  end
end
